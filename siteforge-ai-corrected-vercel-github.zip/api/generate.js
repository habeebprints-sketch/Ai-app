const https = require("https");

function fetchText(url, timeout=8000){
  return new Promise((resolve,reject)=>{
    const req=https.get(url,{headers:{
      "User-Agent":"SiteForgeAI/1.0",
      "Accept":"text/html,text/plain;q=0.9,*/*;q=0.1"
    }},res=>{
      if(res.statusCode>=300 && res.statusCode<400 && res.headers.location){
        return resolve(fetchText(new URL(res.headers.location,url).toString(),timeout));
      }
      if(res.statusCode!==200){res.resume();return reject(new Error("Website could not be fetched."));}
      let data="";
      res.setEncoding("utf8");
      res.on("data",chunk=>{data+=chunk;if(data.length>60000)req.destroy();});
      res.on("end",()=>resolve(data.slice(0,60000)));
    });
    req.setTimeout(timeout,()=>req.destroy(new Error("Website request timed out.")));
    req.on("error",reject);
  });
}

function stripHtml(html){
  return html
    .replace(/<script[\s\S]*?<\/script>/gi," ")
    .replace(/<style[\s\S]*?<\/style>/gi," ")
    .replace(/<svg[\s\S]*?<\/svg>/gi," ")
    .replace(/<[^>]+>/g," ")
    .replace(/\s+/g," ")
    .trim()
    .slice(0,12000);
}

function extractJson(text){
  const cleaned=text.replace(/```json|```/g,"").trim();
  const start=cleaned.indexOf("{");
  const end=cleaned.lastIndexOf("}");
  if(start<0||end<0)throw new Error("AI returned invalid website data.");
  return JSON.parse(cleaned.slice(start,end+1));
}

module.exports=async(req,res)=>{
  if(req.method!=="POST")return res.status(405).json({error:"Method not allowed."});
  if(!process.env.OPENAI_API_KEY)return res.status(500).json({error:"OPENAI_API_KEY is missing. Add it in Vercel Environment Variables."});

  try{
    const {prompt,url}=req.body||{};
    if(!prompt)return res.status(400).json({error:"Website prompt is required."});

    let reference="";
    if(url){
      let parsed;
      try{parsed=new URL(url)}catch{return res.status(400).json({error:"Invalid website URL."});}
      if(!["http:","https:"].includes(parsed.protocol))return res.status(400).json({error:"Only http/https URLs are supported."});
      try{reference=stripHtml(await fetchText(parsed.toString()))}catch(e){reference="The reference website could not be fetched; create the site from the user's prompt."}
    }

    const model=process.env.OPENAI_MODEL||"gpt-5.6-luna";
    const input=`Create a complete responsive website from this request:

USER REQUEST:
${prompt}

${reference?`REFERENCE WEBSITE TEXT (use only for general structure/inspiration; do not copy protected text, images, logos, or branding):
${reference}`:"No reference website was supplied."}

Return ONLY valid JSON with exactly these string fields:
{"html":"...","css":"...","js":"..."}

Rules:
- Use semantic HTML.
- Modern responsive CSS.
- Vanilla JavaScript only.
- Make interactions functional where practical.
- Do not include markdown fences.
- Do not include secret keys.
- Do not add platform watermarks or platform branding.
- Keep HTML, CSS and JavaScript separate.`;

    const api=await fetch("https://api.openai.com/v1/responses",{
      method:"POST",
      headers:{
        "Content-Type":"application/json",
        "Authorization":`Bearer ${process.env.OPENAI_API_KEY}`
      },
      body:JSON.stringify({model,input})
    });
    const data=await api.json();
    if(!api.ok)return res.status(api.status).json({error:data.error?.message||"OpenAI request failed."});

    const result=extractJson(data.output_text||"");
    return res.status(200).json(result);
  }catch(e){
    return res.status(500).json({error:e.message||"Generation failed."});
  }
};
