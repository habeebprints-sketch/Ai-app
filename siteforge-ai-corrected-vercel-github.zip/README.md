# SiteForge AI — corrected GitHub/Vercel starter

This version fixes the main problem with GitHub Pages: the AI request now runs in a Vercel serverless function at `/api/generate`.

## Important

**Do not deploy this as GitHub Pages alone.**

GitHub is where you can store the code. Deploy the repository to **Vercel** so `/api/generate` can run.

## Setup

1. Upload this entire folder to a GitHub repository.
2. Import that repository into Vercel.
3. In Vercel, open Project Settings → Environment Variables.
4. Add:

`OPENAI_API_KEY` = your OpenAI API key

Optional:

`OPENAI_MODEL` = `gpt-5.6-luna`

5. Redeploy.
6. Open the Vercel URL.

The frontend calls `/api/generate`, so there is no GitHub Pages cross-domain configuration needed.

## What works

- Text prompt → HTML/CSS/JS website
- Optional public website URL used as reference
- Live preview
- Editable HTML/CSS/JS
- Download generated website as an HTML file
- No platform watermark is added to generated websites

## Security

Never put `OPENAI_API_KEY` in `app.js` or `index.html`, and never commit `.env` to GitHub.

The URL reference fetch is a starter implementation. For a production app, add stronger SSRF protections, URL allow/deny rules, rate limiting, authentication, and content-length controls.

The AI API is paid separately according to the provider's current pricing.
