const state={html:"",css:"",js:"",tab:"html"};
const $=s=>document.querySelector(s);
const editor=$("#editor"), preview=$("#preview"), status=$("#status");

function save(){state[state.tab]=editor.value}
function load(){editor.value=state[state.tab]||""}
function render(){
  save();
  const safeJS=state.js.replace(/<\/script/gi,"<\\\\/script");
  preview.srcdoc=`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>${state.css}</style></head><body>${state.html}<script>${safeJS}<\/script></body></html>`;
}
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{
  save();
  $(".tab.active").classList.remove("active");
  b.classList.add("active");
  state.tab=b.dataset.tab;
  load();
});
editor.oninput=()=>{state[state.tab]=editor.value;render()};
$("#refreshBtn").onclick=render;

$("#generateBtn").onclick=async()=>{
  const prompt=$("#prompt").value.trim();
  const url=$("#websiteUrl").value.trim();
  if(!prompt){status.textContent="Please describe the website first.";return}
  if(url && !/^https?:\/\/\S+$/i.test(url)){status.textContent="Enter a valid http/https website URL.";return}

  $("#generateBtn").disabled=true;
  status.textContent="Generating website…";
  try{
    const r=await fetch("/api/generate",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({prompt,url})
    });
    const data=await r.json();
    if(!r.ok)throw new Error(data.error||"Generation failed.");
    state.html=data.html||"";
    state.css=data.css||"";
    state.js=data.js||"";
    state.tab="html";
    $(".tab.active").classList.remove("active");
    document.querySelector('[data-tab="html"]').classList.add("active");
    load(); render();
    status.textContent="Website generated successfully.";
  }catch(e){status.textContent=e.message}
  finally{$("#generateBtn").disabled=false}
};

$("#downloadBtn").onclick=()=>{
  save();
  const html=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Generated Website</title><link rel="stylesheet" href="style.css"></head><body>${state.html}<script src="app.js"><\/script></body></html>`;
  const js=state.js;
  const css=state.css;
  const readme="# Generated Website\\n\\nOpen index.html in a browser.\\n";
  const content=[["index.html",html],["style.css",css],["app.js",js],["README.txt",readme]];
  // Download a simple multi-file project without another server.
  // Files are combined into a .tar-like text only if browser ZIP libraries aren't loaded.
  // To keep this starter dependency-free, download the three files individually as a single HTML package.
  const blob=new Blob([html],{type:"text/html"});
  const a=document.createElement("a");
  a.href=URL.createObjectURL(blob);
  a.download="generated-website.html";
  a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);
};

state.html="<section style='font-family:Arial;padding:60px;text-align:center'><h1>Your website will appear here</h1><p>Describe your idea and click Generate Website.</p></section>";
load();render();
